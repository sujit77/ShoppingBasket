﻿using ShoppingBasketPriceCalculator.BusinessDomain;
using ShoppingBasketPriceCalculator.Enums;
using ShoppingBasketPriceCalculator.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;


namespace ShoppingBasketPriceCalculator.Discounts
{
    public class HalfPriceDiscount : IDiscount
    {
        private readonly ProductQuantity _productsThatQualifyBasketforDiscount;
        private readonly DiscountedProduct _discountProduct;

        public HalfPriceDiscount(ProductQuantity productsThatQualifyBasketforDiscount, DiscountedProduct discountProduct)
        {
            if (productsThatQualifyBasketforDiscount != null)
            {
                _productsThatQualifyBasketforDiscount = productsThatQualifyBasketforDiscount;
            }            
            if (discountProduct != null)
            {                
                _discountProduct = discountProduct;
            }
            if (productsThatQualifyBasketforDiscount==null)
            throw new ArgumentNullException(nameof(productsThatQualifyBasketforDiscount));
            if (discountProduct == null)
            throw new ArgumentNullException(nameof(discountProduct));

        }
        private decimal ApplyDiscount(Product item) => (item.UnitPrice * 0.5m);

        public IEnumerable<AppliedDiscount> DiscountsApplicable(IEnumerable<ProductQuantity> items)
        {
            var itemsArray = items as ProductQuantity[] ?? items.ToArray();

            var discountsApplied = new List<AppliedDiscount>();

            foreach (var item in itemsArray)
            {
                if (item.Product.ProductId == _productsThatQualifyBasketforDiscount.Product.ProductId && item.Quantity >= _productsThatQualifyBasketforDiscount.Quantity)
                {
                    var halfPriceItems = itemsArray
                        .Where(halfPriceItem => halfPriceItem.Product.ProductId == _discountProduct.ProductId)
                        .ToArray();

                    if (halfPriceItems.Length > 0)
                    {
                        var discount = ApplyDiscount(halfPriceItems[0].Product);

                        discountsApplied.Add(new AppliedDiscount
                        {
                            Type = DiscountType.HalfPrice,
                            Text = $"{_discountProduct.Name} 50% OFF: - {discount.ToCurrencyString()}",
                            Amount = discount
                        });
                    }
                }
            }

            return discountsApplied;
        }
    }
}
