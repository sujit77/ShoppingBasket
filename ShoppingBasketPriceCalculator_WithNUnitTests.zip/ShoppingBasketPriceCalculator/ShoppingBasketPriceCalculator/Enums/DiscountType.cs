﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShoppingBasketPriceCalculator.Enums
{
    public enum DiscountType
    {
        None,
        Percentage,
        HalfPrice
    }
}
