﻿using ShoppingBasketPriceCalculator.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShoppingBasketPriceCalculator.BusinessDomain
{
    public class AppliedDiscount
    {
        public DiscountType Type { get; set; }
        public string Text { get; set; }
        public decimal Amount { get; set; }
    }
}
