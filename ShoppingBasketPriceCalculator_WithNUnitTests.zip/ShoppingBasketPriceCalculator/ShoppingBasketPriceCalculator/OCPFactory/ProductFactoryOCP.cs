﻿using ShoppingBasketPriceCalculator.BusinessDomain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShoppingBasketPriceCalculator.OCPFactory
{
    // this is a product factory class not to violate SOLID's Open closed principle
    public  class ProductFactoryOCP
    {

        private Dictionary<string, Product> productRegistry = new Dictionary<string, Product>();

        public void addProductToRegistry(string productName, Product product)
        {
            productRegistry.Add(productName, product);
        }
        public Product GetProduct(string productName)
        {
            if (productRegistry.ContainsKey(productName.ToLower()))
            {
                return productRegistry[productName];
            }
            else
                throw new NotSupportedException($"Unrecognized product name : {productName.ToLower()}");
        }
    }
}
