﻿using ShoppingBasketPriceCalculator.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;


namespace ShoppingBasketPriceCalculator
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                if (args == null || args.Length == 0)
                {
                    Console.WriteLine("No products passed in!");
                    Console.ReadLine();
                }
                else
                {
                    var products = new List<string>();

                    foreach (var arg in args)
                    {
                        products.Add(arg.ToLower());
                    }

                    var specialOffers = OffersInitializer.CreateDiscounts();

                    // lets inject possible offers into the shopping basket
                    var basket = new ShoppingBasket.ShoppingBasket(specialOffers);

                    // now initialise mapping of product object for each product type in scope of this test 
                    //with corresponding product's string name that is input to the app
                    var productCatalogueHelper = new ProductCatalogueHelper();
                    productCatalogueHelper.AddProductsToFactoryRegistryToAbideOpenClosedPrinciple();

                    // now add the quantity of each product along with unit price details into the basket 
                    basket.AddProducts(productCatalogueHelper.CreateProducts(products));

                    // this will get the total price of items in the basket without any discounts applies
                    var subTotal = basket.SubTotal;

                    // now get discounts from the basket 
                    var discountsApplied = basket.GetBasketDiscounts().ToArray();

                    // now subtract sum of all discounts applicable from subTotal to get the final price after discounts applied
                    var totalPrice = subTotal - discountsApplied.Sum(item => item.Amount);

                    Console.WriteLine("SubTotal : " + $"{subTotal.ToCurrencyString()}");

                    // write discounts text to console
                    foreach (var discount in discountsApplied)
                    {
                        Console.WriteLine(discount.Text);
                    }

                    // write total price after discounts with currency formatting to string
                    Console.WriteLine("Total Price : " + $"{totalPrice.ToCurrencyString()}");
                    Console.ReadLine();
                }
            }
            catch (Exception ex)
            {
                // Log error using some framework like Log4Net

                Console.WriteLine(ex);
                throw new ApplicationException("An application error occurred", ex);
            }
        }
    }
}
