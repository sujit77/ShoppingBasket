﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShoppingBasketPriceCalculator.Helpers
{
    public static class DecimalToStringFormatterExtension
    {
        public static string ToCurrencyString(this decimal value)
        {
            return value < 1 ? $"{(int)(value * 100)}p" : $"{value:C}";
        }
    }
}
