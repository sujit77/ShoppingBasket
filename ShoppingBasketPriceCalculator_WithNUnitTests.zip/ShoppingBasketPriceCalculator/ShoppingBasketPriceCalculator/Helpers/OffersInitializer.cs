﻿using ShoppingBasketPriceCalculator.BusinessDomain;
using ShoppingBasketPriceCalculator.Discounts;
using ShoppingBasketPriceCalculator.OCPFactory;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ShoppingBasketPriceCalculator.Helpers
{
    public static class OffersInitializer
    {       

        // This discounts list would be read from a configuration file or database as not to change the code 
        // everytime a discount was added/amended/removed, you can see here that different type of offers can be added 
        // each offer implementations constructor can take the rules parameter to build the rule for offer and will vary from 
        // one rule to other 
        public static IEnumerable<IDiscount> CreateDiscounts()        {
            

            return new List<IDiscount>
            {
                new PercentageDiscount( new DiscountedProduct
                        {
                            ProductId = 1,
                            Name = "Apples"
                        }
                    ,
                    0.10m)
                    ,

                new HalfPriceDiscount(
                    new ProductQuantity
                    {
                        Product = new Product() {ProductId=2,Name="Beans" },
                        Quantity = 2

                    },
                    new DiscountedProduct()
                    {
                        ProductId = 3,
                        Name = "Bread"
                    })
            };
        }
    }
    }
