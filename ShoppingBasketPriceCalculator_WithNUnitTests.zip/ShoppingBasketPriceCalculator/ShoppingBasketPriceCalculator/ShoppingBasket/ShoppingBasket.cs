﻿using ShoppingBasketPriceCalculator.BusinessDomain;
using ShoppingBasketPriceCalculator.Discounts;
using ShoppingBasketPriceCalculator.Enums;
using System;
using System.Collections.Generic;
using System.Linq;


namespace ShoppingBasketPriceCalculator.ShoppingBasket
{
    public class ShoppingBasket : IShoppingBasket
    {
        private readonly IEnumerable<IDiscount> _listOfOffers;
        private readonly List<ProductQuantity> _productItems;

        public ShoppingBasket(IEnumerable<IDiscount> discounts)
        {
            if (discounts == null)
                throw new ArgumentNullException();
            else
            {
                _listOfOffers = discounts;
            _productItems = new List<ProductQuantity>();
            }
        }

        public void AddProducts(IEnumerable<ProductQuantity> productItems)
        {
            _productItems.AddRange(productItems);
        }

        public int ProductCount => _productItems.Count;

        public decimal SubTotal => _productItems.Sum(item => item.Product.UnitPrice * item.Quantity);

        public IEnumerable<AppliedDiscount> GetBasketDiscounts()
        {
            var discounts = new List<AppliedDiscount>();

            foreach (var discount in _listOfOffers)
            {
                // send all products to each offer rule and get applicable discounts
                discounts.AddRange(discount.DiscountsApplicable(_productItems));
            }

            // if we have not applicable offers then create None type of discount 
            if (!discounts.Any())
                discounts.Add(new AppliedDiscount
                {
                    Type = DiscountType.None,
                    Text = "(No offers available)",
                    Amount = 0.00m
                });

            return discounts;
        }
    }
}
