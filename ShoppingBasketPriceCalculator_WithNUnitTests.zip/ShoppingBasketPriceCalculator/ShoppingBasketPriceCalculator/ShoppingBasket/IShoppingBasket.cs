﻿using ShoppingBasketPriceCalculator.BusinessDomain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShoppingBasketPriceCalculator.ShoppingBasket
{
    public interface IShoppingBasket
    {
        void AddProducts(IEnumerable<ProductQuantity> items);
        int ProductCount { get; }
        decimal SubTotal { get; }
        IEnumerable<AppliedDiscount> GetBasketDiscounts();
    }
}
