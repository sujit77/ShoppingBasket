﻿
using ShoppingBasketPriceCalculator.ShoppingBasket;
using ShoppingBasketPriceCalculator.Discounts;
using System;
using System.Collections.Generic;
using UnitTests.Helper;
using NUnit.Framework;
using ShoppingBasketPriceCalculator.Enums;
using Moq;
using ShoppingBasketPriceCalculator.BusinessDomain;
using System.Linq;

namespace UnitTests
{
    [TestFixture]
    public class ShoppingBasketUnitTests
    {
        ProductQuantityHelper _pHelper;
        ProductQuantityHelper _pHelperShared;   
        

        [SetUp]
        public void SetUp()
        {
            _pHelperShared = new ProductQuantityHelper();

        }
        private void ProductQuantityHelperSetUp()
        {
            _pHelper = new ProductQuantityHelper();
        }
        [Test]
        public void ShoppingBasket_Discounts_IsNull_ExceptionThrown()
        {
            // Arrange + Act + Assert            

            Assert.Throws<ArgumentNullException>(() => new ShoppingBasket(null));
        }

        [Test]
        [TestCase(2)]
        [TestCase(8)]
        [TestCase(5)]
        public void ShoppingBasket_AddProducts_CheckProductsCount(int productsToCreate)
        {
            // Arrange             
            var shoppingBasket = new ShoppingBasket(new List<IDiscount>());
            shoppingBasket.AddProducts(_pHelperShared.CreateProducts(productsToCreate));

            // Act
            var result = shoppingBasket.ProductCount;

            // Assert
            Assert.AreEqual(result, productsToCreate);
        }

        [Test]
        public void ShoppingBasket_CheckCalculateSubTotal_WithNoDiscounts()
        {
            // Arrange             
            var shoppingBasket = new ShoppingBasket(new List<IDiscount>());
            ProductQuantityHelperSetUp();
            shoppingBasket.AddProducts(_pHelper.CreateProducts());

            // Act
            var result = shoppingBasket.SubTotal;

            // Assert
            Assert.AreEqual(result, 3.23m);
        }

        [Test]
        public void ShoppingBasket_CheckCalculateTotalPrice_WithNoDiscounts()
        {
            // Arrange             
            var shoppingBasket = new ShoppingBasket(new List<IDiscount>());
            ProductQuantityHelperSetUp();
            shoppingBasket.AddProducts(_pHelper.CreateProducts());

            // Act
            var result = shoppingBasket.SubTotal - shoppingBasket.GetBasketDiscounts().Sum(item => item.Amount);

            // Assert
            Assert.AreEqual(result, 3.23m);
        }

        [Test]
        public void ShoppingBasket_CheckCalculateTotalPrice_WithPercentageDiscount()
        {
            // Arrange
            var percentageDiscount = new Mock<IDiscount>();

            percentageDiscount.Setup(mock => mock.DiscountsApplicable(It.IsAny<IEnumerable<ProductQuantity>>()))
                .Returns(DiscountHelper.CreatePercentageAppliedDiscount());

            var shoppingBasket = new ShoppingBasket(new List<IDiscount> { percentageDiscount.Object });
            ProductQuantityHelperSetUp();
            shoppingBasket.AddProducts(_pHelper.CreateProducts());

            // Act
            var discountsTotal = shoppingBasket.GetBasketDiscounts().Sum(item => item.Amount);
            var result = shoppingBasket.SubTotal - discountsTotal;

            // Assert
            Assert.AreEqual(result, 3.20m);
        }

        [Test]
        public void ShoppingBasket_CheckCalculateTotalPrice_WithHalfPriceDiscount()
        {
            // Arrange         
            var halfPriceDiscount = new Mock<IDiscount>();

            halfPriceDiscount.Setup(mock => mock.DiscountsApplicable(It.IsAny<IEnumerable<ProductQuantity>>()))
                .Returns(DiscountHelper.CreateHalfPriceAppliedDiscount);

            var shoppingBasket = new ShoppingBasket(new List<IDiscount> { halfPriceDiscount.Object });
            ProductQuantityHelperSetUp();
            shoppingBasket.AddProducts(_pHelper.CreateProducts());

            // Act
            var discountsTotal = shoppingBasket.GetBasketDiscounts().Sum(item => item.Amount);
            var result = shoppingBasket.SubTotal - discountsTotal;

            // Assert
            Assert.AreEqual(result, 2.83m);
        }

        [Test]
        public void ShoppingBasket_CheckCalculateTotalPrice_WitMultipleDiscounts()
        {
            // Arrange    
            var multlpleDiscounts = new Mock<IDiscount>();

            multlpleDiscounts.Setup(mock => mock.DiscountsApplicable(It.IsAny<IEnumerable<ProductQuantity>>()))
                .Returns(DiscountHelper.CreateMultipleAppliedDiscounts());

            var shoppingBasket = new ShoppingBasket(new List<IDiscount> { multlpleDiscounts.Object });
            ProductQuantityHelperSetUp();
            shoppingBasket.AddProducts(_pHelper.CreateProducts());

            // Act
            var discountsTotal = shoppingBasket.GetBasketDiscounts().Sum(item => item.Amount);
            var result = shoppingBasket.SubTotal - discountsTotal;

            // Assert
            Assert.AreEqual(result, 2.80m);
        }

        [Test]
        public void ShoppingBasket_GetBasketDiscounts_WithNoDiscountApplied()
        {
            // Arrange
            var discounts = new Mock<IDiscount>();

            discounts.Setup(mock => mock.DiscountsApplicable(It.IsAny<IEnumerable<ProductQuantity>>()))
                .Returns(DiscountHelper.CreateNoDiscountApplied);

            var shoppingBasket = new ShoppingBasket(new List<IDiscount> { discounts.Object });
            ProductQuantityHelperSetUp();
            shoppingBasket.AddProducts(_pHelper.CreateProducts());

            // Act
            var result = shoppingBasket.GetBasketDiscounts().ToArray();

            // Assert
            Assert.AreEqual(result.Any(), true);
            Assert.AreEqual(result[0].Type, DiscountType.None);
            Assert.AreEqual(result[0].Amount, 0.00m);
            Assert.AreEqual(result[0].Text, "(No offers available)");
        }
    }
}
