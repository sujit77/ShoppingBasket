﻿using NUnit.Framework;
using ShoppingBasketPriceCalculator.BusinessDomain;
using ShoppingBasketPriceCalculator.Discounts;
using ShoppingBasketPriceCalculator.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnitTests.Helper;

namespace UnitTests
{
    [TestFixture]
    public class PercentageDiscountsTest
    {
        ProductQuantityHelper _pHelper;
        
        private void ProductQuantityHelperSetUp()
        {
            _pHelper = new ProductQuantityHelper();
        }

        [Test]        
        public void PercentageDiscount_DiscountedItems_IsNull_ExceptionThrown()
        {
            // Arrange + Act + Assert
                    

            Assert.Throws<ArgumentNullException>(() => new PercentageDiscount(null, 0.10m));
        }

        [Test]
        public void PercentageDiscount_NoDiscountApplied_With10PercentDiscount()
        {
            // Arrange
            var percentageDiscount = new PercentageDiscount(new DiscountedProduct
            {
                ProductId = 4,
                Name = "Milk"
            }, 0.10m);
            ProductQuantityHelperSetUp();

            // Act

            var result = percentageDiscount.DiscountsApplicable(_pHelper.CreateProducts()).ToArray();

            // Assert
            Assert.AreEqual(result.Any(), false);
        }

        [Test]
        public void PercentageDiscount_CalculateAppliedDiscount_With10PercentDiscount()
        {
            // Arrange
            var percentageDiscount = new PercentageDiscount(DiscountHelper.CreateDiscountedProducts(), 0.10m);
            ProductQuantityHelperSetUp();
            // Act

            var result = percentageDiscount.DiscountsApplicable(_pHelper.CreateProducts()).ToArray();

            // Assert
            Assert.AreEqual(result.Any(), true);
            Assert.AreEqual(result[0].Type, DiscountType.Percentage);
            Assert.AreEqual(result[0].Amount, 0.03m);
            Assert.AreEqual(result[0].Text, "Apples 10% OFF: - 3p");
        }

        [Test]
        public void PercentageDiscount_CalculateAppliedDiscount_With50PercentDiscount()
        {
            // Arrange
            var percentageDiscount = new PercentageDiscount(DiscountHelper.CreateDiscountedProducts(), 0.50m);
            ProductQuantityHelperSetUp();

            // Act
            var result = percentageDiscount.DiscountsApplicable(_pHelper.CreateProducts()).ToArray();

            // Assert
            Assert.AreEqual(result.Any(), true);
            Assert.AreEqual(result[0].Type, DiscountType.Percentage);
            Assert.AreEqual(result[0].Amount, 0.16m);
            Assert.AreEqual(result[0].Text, "Apples 50% OFF: - 16p");
        }
    }
}
