﻿using System.Collections.Generic;
using ShoppingBasketPriceCalculator.BusinessDomain;

namespace UnitTests.Helper
{
    public class ProductQuantityHelper
    {
        public  IEnumerable<ProductQuantity> CreateProducts(int numberOfProductsToCreate)
        {
            var products = new List<ProductQuantity>();            

            for (int i = 0; i < numberOfProductsToCreate; i++)
            {
               
                products.Add(new ProductQuantity
                {
                    Product = BuildProduct("TestProduct",i,1.00m),
                    Quantity = 1
                });
            }

            return products;
        }

        private Product BuildProduct(string name,int pId, decimal UnitPrice)
        {
            return new Product() { Name= name,ProductId = pId, UnitPrice = UnitPrice };
        }

        public IEnumerable<ProductQuantity> CreateProducts()
        {
            return new List<ProductQuantity>
            {
                new ProductQuantity
                {
                    Product = BuildProduct("Apples",1,0.33m),                                            
                    Quantity = 1
                },
                new ProductQuantity
                {
                    Product = BuildProduct("Beans",2,0.65m),
                    Quantity = 2
                },
                new ProductQuantity
                {
                    Product = BuildProduct("Bread",3,0.80m),
                    Quantity = 2
                }
            };
        }

        public  IEnumerable<ProductQuantity> CreateProductsForHalfPriceDiscounts()
        {
            return new List<ProductQuantity>
            {
                new ProductQuantity
                {
                    Product = BuildProduct("Apples",1,0.33m),
                    Quantity = 1
                },
                new ProductQuantity
                {
                    Product = BuildProduct("Beans",2,0.65m),                                            
                    Quantity = 4
                },
                new ProductQuantity
                {
                    Product = BuildProduct("Bread",3,0.80m),
                    Quantity = 2
                }
            };
        }
    }
}
