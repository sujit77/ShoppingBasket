﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using ShoppingBasketPriceCalculator.ShoppingBasket;
using ShoppingBasketPriceCalculator.Discounts;
using System;
using System.Collections.Generic;
using UnitTests.Helper;

namespace UnitTests
{
    [TestClass]
    public class ShoppingBasketUnitTests
    {
        ProductQuantityHelper _pHelper;

        [TestInitialize]
        public void SetUp()
        {
            _pHelper = new ProductQuantityHelper();
        }
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void ShoppingBasket_Discounts_IsNull_ExceptionThrown()
        {
            // Arrange + Act + Assert
            var shoppingBasket = new ShoppingBasket(null);
        }

        [TestMethod]
        [DataRow(2)]
        [DataRow(8)]
        [DataRow(5)]
        public void ShoppingBasket_AddProducts_CheckProductsCount(int productsToCreate)
        {
            // Arrange             
            var shoppingBasket = new ShoppingBasket(new List<IDiscount>());
            shoppingBasket.AddProducts(_pHelper.CreateProducts(productsToCreate));

            // Act
            var result = shoppingBasket.ProductCount;

            // Assert
            Assert.AreEqual(result, productsToCreate);
        }
    }
}
