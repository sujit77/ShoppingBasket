﻿using ShoppingBasketPriceCalculator.BusinessDomain;
using ShoppingBasketPriceCalculator.OCPFactory;
using System;
using System.Collections.Generic;
using System.Linq;


namespace ShoppingBasketPriceCalculator.Helpers
{
    public class ProductCatalogueHelper
    {
        public ProductCatalogueHelper ()
        {
            _pfactoryWithOpenClosedPrincipleInMind =  new ProductFactoryOCP();
        }
        readonly ProductFactoryOCP _pfactoryWithOpenClosedPrincipleInMind;
        public void AddProductsToFactoryRegistryToAbideOpenClosedPrinciple()
        {
            // we create products as lower case keys of the registry and use ToLower in our look up call
            _pfactoryWithOpenClosedPrincipleInMind.addProductToRegistry("apple", new Product
            {
                ProductId = 1,
                Name = "Apple",
                UnitPrice = 1.00m
            });

            _pfactoryWithOpenClosedPrincipleInMind.addProductToRegistry("beans", new Product
            {
                ProductId = 2,
                Name = "Beans",
                UnitPrice = 0.65m
            });
            _pfactoryWithOpenClosedPrincipleInMind.addProductToRegistry("bread", new Product
            {
                ProductId = 3,
                Name = "Bread",
                UnitPrice = 0.80m
            });
            _pfactoryWithOpenClosedPrincipleInMind.addProductToRegistry("milk", new Product
            {
                ProductId = 4,
                Name = "Milk",
                UnitPrice = 1.30m
            });


        }

        public  IEnumerable<ProductQuantity> CreateProducts(IEnumerable<string> products)
        {
            var productsAndQuantities = new List<ProductQuantity>();

            //var productFactory = new ProductFactoryOCP();


            foreach (var product in products)
            {
                var existProduct = productsAndQuantities.SingleOrDefault(item =>
                    string.Equals(item.Product.Name, product, StringComparison.CurrentCultureIgnoreCase));

                if (existProduct == null)
                {

                    productsAndQuantities.Add(new ProductQuantity
                    {
                        Product = _pfactoryWithOpenClosedPrincipleInMind.GetProduct(product),
                        Quantity = 1
                    });
                }

                if (existProduct != null)
                    existProduct.Quantity += 1;
            }

            return productsAndQuantities;
        }
    }
}
