﻿using ShoppingBasketPriceCalculator.BusinessDomain;
using System.Collections.Generic;


namespace ShoppingBasketPriceCalculator.Discounts
{
    // this will serve as strategy pattern to add additional offers as need arises , for now two offers have been implemented HalfPriceDiscount and PercentageDicount
    public interface IDiscount
    {
        IEnumerable<AppliedDiscount> DiscountsApplicable(IEnumerable<ProductQuantity> items);
    }
}
